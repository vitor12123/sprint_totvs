CREATE TABLE conv (
	id_conv INT PRIMARY KEY,
    id_meet int not null,
    dt_conv datetime,
	tr_conv longtext,
    st_conv varchar(50)
);

create table clie (
	id_clie int primary key,
    nm_clie varchar(100),
	nota_nps DECIMAL(5,2),
    dt_ultima_pesquisa DATE
);

